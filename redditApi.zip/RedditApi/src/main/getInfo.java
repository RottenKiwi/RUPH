package main;

import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

import com.google.gson.Gson;

public class getInfo {
	
	private static String streamToString(InputStream inputStream) {
	    String text = new Scanner(inputStream, "UTF-8").useDelimiter("\\Z").next();
	    return text;
	  }

	 public static String getPostInfo(String username) {
		    String json = null;
		    try {
		      URL url = new URL("https://api.pushshift.io/reddit/search/submission/?author="+username+"&sort=asc&size=100");
		      HttpURLConnection connection = (HttpURLConnection) url.openConnection();
		      connection.setDoOutput(true);
		      connection.setInstanceFollowRedirects(false);
		      connection.setRequestMethod("GET");
		      connection.setRequestProperty("Content-Type", "application/json");
		      connection.setRequestProperty("charset", "utf-8");
		      connection.connect();
		      InputStream inStream = connection.getInputStream();
		      json = streamToString(inStream);
		      
		      Gson gson=new Gson();
		      Datalist data=gson.fromJson(json, Datalist.class);
		      FileWriter file=new FileWriter( "/Users/�����/Desktop/userposts.txt");
		      
		     
		      int i;
		      int counter=0;
		      for(i=0;i<data.getData().size();i++) {
		    	  
		    	  sortedInfo sorted=new sortedInfo();
		    	  sorted.setAuthor(data.getData().get(counter).getAuthor());
		    	  sorted.setPostBody(data.getData().get(counter).getSelftext());
		    	  sorted.setSubreddit(data.getData().get(counter).getSubreddit());
		    	  
		    	  counter++;
		    	  System.out.println("---------------");
		    	  System.out.println("Author name: "+sorted.getAuthor()+" ,Postbody: "+sorted.getPostBody()+"  ,Subreddit: "+sorted.getSubreddit());
		    	  System.out.println("---------------");
		      }
		      
		      
		      
		      
		      String jsonInString=gson.toJson(data);
		      
		      
		      
		    } catch (IOException ex) {
		      ex.printStackTrace();
		    }
		    return json;
		  }
	
}
