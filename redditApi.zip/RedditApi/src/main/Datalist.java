package main;

import java.util.ArrayList;

public class Datalist {
	ArrayList<Data> data = new ArrayList<Data>();

	public ArrayList<Data> getData() {
		return data;
	}

	public void setData(ArrayList<Data> data) {
		this.data = data;
	}
	
	
	
}
