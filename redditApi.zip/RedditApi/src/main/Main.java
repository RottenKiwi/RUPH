package main;

public class Main {

	public static void main(String[] args) {


getInfo.getPostInfo("know2fart");
getInfo.getPostInfo("02grimreaper");
	}

}
